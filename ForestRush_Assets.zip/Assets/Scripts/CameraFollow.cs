using UnityEngine;

/// <summary>Smooth third-person chase camera. In the main menu it slowly orbits the player.</summary>
public class CameraFollow : MonoBehaviour
{
    public Transform Target;

    const float BlendTime = 1.0f;
    const float HeightOffset = 4.4f;
    const float BackOffset = -8f;

    bool menuMode = true;
    float orbit = 160f;
    float smX, smY = HeightOffset;
    float blendT;
    Vector3 fromPos;
    Quaternion fromRot;
    float shakeTime, shakeDur, shakeMag;

    public void SetMenuMode(bool menu)
    {
        menuMode = menu;
        blendT = BlendTime;
        fromPos = transform.position;
        fromRot = transform.rotation;
        if (menu) orbit = 160f;
    }

    public void Shake(float magnitude, float duration)
    {
        shakeMag = magnitude; shakeDur = Mathf.Max(0.01f, duration); shakeTime = duration;
    }

    public void Snap()
    {
        if (Target == null) return;
        blendT = 0f;
        smX = Target.position.x * 0.6f;
        smY = HeightOffset;
        Vector3 pos; Quaternion rot;
        Compute(out pos, out rot);
        transform.SetPositionAndRotation(pos, rot);
    }

    void Compute(out Vector3 pos, out Quaternion rot)
    {
        Vector3 tp = Target.position;
        if (menuMode)
        {
            float a = orbit * Mathf.Deg2Rad;
            Vector3 center = tp + new Vector3(0f, 1.1f, 0f);
            pos = center + new Vector3(Mathf.Sin(a) * 5.2f, 1.2f, Mathf.Cos(a) * 5.2f);
            rot = Quaternion.LookRotation(center - pos, Vector3.up);
        }
        else
        {
            pos = new Vector3(smX, smY, tp.z + BackOffset);
            Vector3 look = new Vector3(tp.x * 0.3f, 1.3f, tp.z + 9f);
            rot = Quaternion.LookRotation(look - pos, Vector3.up);
        }
    }

    void LateUpdate()
    {
        if (Target == null) return;
        float dt = Time.deltaTime;

        if (menuMode) orbit += 14f * dt;
        else
        {
            Vector3 tp = Target.position;
            smX = Mathf.Lerp(smX, tp.x * 0.6f, 1f - Mathf.Exp(-9f * dt));
            smY = Mathf.Lerp(smY, HeightOffset + Mathf.Max(0f, tp.y) * 0.3f, 1f - Mathf.Exp(-7f * dt));
        }

        Vector3 pos; Quaternion rot;
        Compute(out pos, out rot);

        if (blendT > 0f)
        {
            blendT -= dt;
            float w = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(blendT / BlendTime));
            pos = Vector3.Lerp(pos, fromPos, w);
            rot = Quaternion.Slerp(rot, fromRot, w);
        }

        if (shakeTime > 0f)
        {
            shakeTime -= dt;
            pos += Random.insideUnitSphere * shakeMag * Mathf.Clamp01(shakeTime / shakeDur);
        }
        transform.SetPositionAndRotation(pos, rot);
    }
}
