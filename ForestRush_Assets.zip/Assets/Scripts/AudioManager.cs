using UnityEngine;

/// <summary>
/// All sounds are SYNTHESIZED in code (no audio files needed): jump, slide, coin, hit, footsteps,
/// button click, forest ambience (wind + birds) and a gentle looping melody.
/// To use your own sounds later, replace the clips assigned in Awake().
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    const int Rate = 22050;
    const float TwoPi = 6.2831853f;
    const string KeySound = "FR_Sound";
    const string KeyMusic = "FR_Music";

    public bool SoundOn { get; private set; }
    public bool MusicOn { get; private set; }

    AudioSource sfx, music, ambience;
    AudioClip jump, slide, coin, hit, click, step;

    void Awake()
    {
        Instance = this;
        SoundOn = PlayerPrefs.GetInt(KeySound, 1) == 1;
        MusicOn = PlayerPrefs.GetInt(KeyMusic, 1) == 1;

        sfx = NewSource("SFX", false, 0.8f);
        music = NewSource("Music", true, 0.30f);
        ambience = NewSource("Ambience", true, 0.55f);

        System.Random rng = new System.Random(11);
        jump = Make("jump", 0.28f, t => Mathf.Sin(TwoPi * (320f + 900f * t) * t) * (1f - t / 0.28f) * 0.5f);
        coin = Make("coin", 0.3f, t => Mathf.Sin(TwoPi * (t < 0.08f ? 988f : 1319f) * t) * Mathf.Exp(-t * 9f) * 0.5f);
        hit = Make("hit", 0.55f, t => (Noise(rng) * Mathf.Exp(-t * 8f) + Mathf.Sin(TwoPi * 60f * t) * Mathf.Exp(-t * 6f)) * 0.8f);
        click = Make("click", 0.08f, t => Mathf.Sin(TwoPi * 640f * t) * Mathf.Exp(-t * 45f) * 0.5f);
        step = Make("step", 0.1f, t => Noise(rng) * Mathf.Exp(-t * 55f) * 0.25f);
        float lp = 0f;
        slide = Make("slide", 0.4f, t => { lp = lp * 0.8f + Noise(rng) * 0.2f; return lp * Mathf.Sin(Mathf.PI * t / 0.4f) * 0.7f; });

        music.clip = MakeMusic();
        ambience.clip = MakeAmbience();
        ApplyMute();
        music.Play();
        ambience.Play();
    }

    AudioSource NewSource(string n, bool loop, float vol)
    {
        AudioSource s = gameObject.AddComponent<AudioSource>();
        s.playOnAwake = false; s.loop = loop; s.volume = vol; s.spatialBlend = 0f;
        return s;
    }

    static float Noise(System.Random r) { return (float)(r.NextDouble() * 2.0 - 1.0); }

    static AudioClip Make(string name, float seconds, System.Func<float, float> gen)
    {
        int n = Mathf.CeilToInt(seconds * Rate);
        float[] data = new float[n];
        for (int i = 0; i < n; i++) data[i] = Mathf.Clamp(gen(i / (float)Rate), -1f, 1f);
        AudioClip clip = AudioClip.Create(name, n, 1, Rate, false);
        clip.SetData(data, 0);
        return clip;
    }

    static AudioClip MakeMusic()
    {
        float[] freqs = { 261.63f, 293.66f, 329.63f, 392f, 440f, 523.25f };
        int[] melody = { 0, 2, 4, 2, 3, 4, 5, 4, 1, 3, 4, 3, 2, 1, 0, 1 };
        float[] bass = { 130.81f, 110f, 146.83f, 98f };
        const float stepLen = 0.3f;
        return Make("music", melody.Length * stepLen, t =>
        {
            int i = Mathf.Min(melody.Length - 1, (int)(t / stepLen));
            float lt = t - i * stepLen;
            float f = freqs[melody[i]];
            float env = Mathf.Exp(-lt * 6f) * Mathf.Min(1f, lt * 200f);
            float s = (Mathf.Sin(TwoPi * f * lt) + 0.3f * Mathf.Sin(TwoPi * 2f * f * lt)) * env * 0.35f;
            int b = Mathf.Min(3, (int)(t / (stepLen * 4f)));
            float bt = t - b * stepLen * 4f;
            float benv = Mathf.Exp(-bt * 1.5f) * Mathf.Min(1f, bt * 100f);
            return s + Mathf.Sin(TwoPi * bass[b] * bt) * benv * 0.3f;
        });
    }

    static AudioClip MakeAmbience()
    {
        System.Random rng = new System.Random(3);
        float lp = 0f;
        float[] chirps = { 0.8f, 1.0f, 3.4f, 3.55f, 3.7f, 6.0f, 6.25f };
        return Make("forest", 8f, t =>
        {
            lp = lp * 0.97f + Noise(rng) * 0.03f;
            float wind = lp * 1.8f * (0.6f + 0.4f * Mathf.Sin(TwoPi * t / 8f));
            float birds = 0f;
            for (int k = 0; k < chirps.Length; k++)
            {
                float u = t - chirps[k];
                if (u >= 0f && u < 0.12f)
                {
                    float f = 3200f + 2500f * (u / 0.12f);
                    birds += Mathf.Sin(TwoPi * f * u) * Mathf.Sin(Mathf.PI * u / 0.12f) * 0.08f;
                }
            }
            return wind * 0.6f + birds;
        });
    }

    // ------------------------------------------------------------ settings
    void ApplyMute()
    {
        music.mute = !MusicOn;
        ambience.mute = !SoundOn;
    }

    public void ToggleSound() { SoundOn = !SoundOn; PlayerPrefs.SetInt(KeySound, SoundOn ? 1 : 0); ApplyMute(); }
    public void ToggleMusic() { MusicOn = !MusicOn; PlayerPrefs.SetInt(KeyMusic, MusicOn ? 1 : 0); ApplyMute(); }

    // ------------------------------------------------------------ play
    void Play(AudioClip c, float vol) { if (SoundOn && c != null) sfx.PlayOneShot(c, vol); }
    public void PlayJump() { Play(jump, 0.6f); }
    public void PlaySlide() { Play(slide, 0.5f); }
    public void PlayCoin() { Play(coin, 0.7f); }
    public void PlayHit() { Play(hit, 1f); }
    public void PlayClick() { Play(click, 0.8f); }
    public void PlayStep() { Play(step, 0.35f); }
}
