using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using PF = ProceduralFactory;

/// <summary>
/// Endless forest. Ground "chunks" (path, grass, trees, bushes, rocks, flowers, hills, mountains)
/// are pooled and recycled behind the player. Obstacle rows and coin patterns are generated ahead
/// of the player and also pooled. Obstacle rows ALWAYS leave at least one lane free.
/// </summary>
public class LevelGenerator : MonoBehaviour
{
    public const float ChunkLength = 30f;
    public const float LaneWidth = 2.2f;
    const int ChunksAhead = 7;
    const int ChunksBehind = 1;
    const float RowSpawnAhead = 140f;
    const float FirstObstacleZ = 70f;

    enum DecorKind { Pine, Round, Bush, Rock, Flower, Log, Mushroom, Hill, Mountain }
    class DecorItem { public Transform T; public DecorKind Kind; }
    class Chunk
    {
        public Transform Root;
        public Renderer Grass;
        public float EndZ;
        public List<DecorItem> Decor = new List<DecorItem>();
    }

    Transform player, chunkRoot, obstacleRoot, coinRoot;
    Material grassA, grassB, pathMat, edgeMat;

    readonly List<Chunk> activeChunks = new List<Chunk>();
    readonly Stack<Chunk> freeChunks = new Stack<Chunk>();
    readonly List<Obstacle> activeObstacles = new List<Obstacle>();
    readonly Stack<Obstacle>[] freeObstacles = new Stack<Obstacle>[5];
    readonly List<Coin> activeCoins = new List<Coin>();
    readonly Stack<Coin> freeCoins = new Stack<Coin>();

    int nextChunkIndex = -1;
    float nextRowZ = 40f, prevRowZ = 6f;
    bool dirty;

    public static float LaneX(int lane) { return (lane - 1) * LaneWidth; }

    public void Init(Transform playerTransform)
    {
        player = playerTransform;
        chunkRoot = NewRoot("Chunks");
        obstacleRoot = NewRoot("Obstacles");
        coinRoot = NewRoot("Coins");
        grassA = PF.Mat("GrassA", "#5DAE3B", 0.03f);
        grassB = PF.Mat("GrassB", "#52A236", 0.03f);
        pathMat = PF.Mat("Path", "#A0703F", 0.02f);
        edgeMat = PF.Mat("PathEdge", "#7E5532", 0.02f);
        for (int i = 0; i < freeObstacles.Length; i++) freeObstacles[i] = new Stack<Obstacle>();
    }

    Transform NewRoot(string n)
    {
        GameObject g = new GameObject(n);
        g.transform.SetParent(transform, false);
        return g.transform;
    }

    /// <summary>Recycles everything and starts the forest again from the player's position.</summary>
    public void ResetWorld()
    {
        if (!dirty && activeChunks.Count > 0) return;   // nothing has changed yet
        for (int i = 0; i < activeChunks.Count; i++) RecycleChunk(activeChunks[i]);
        activeChunks.Clear();
        for (int i = activeObstacles.Count - 1; i >= 0; i--) ReleaseObstacleAt(i);
        for (int i = activeCoins.Count - 1; i >= 0; i--) ReleaseCoinAt(i);
        nextChunkIndex = -1;
        nextRowZ = 40f;
        prevRowZ = 6f;
        dirty = false;
        Maintain(player.position.z);
    }

    void LateUpdate()
    {
        if (player != null) Maintain(player.position.z);
    }

    void Maintain(float pz)
    {
        if (pz > 3f) dirty = true;

        while (nextChunkIndex * ChunkLength < pz + ChunksAhead * ChunkLength) AddChunk();
        while (activeChunks.Count > 0 && activeChunks[0].EndZ < pz - ChunksBehind * ChunkLength)
        {
            RecycleChunk(activeChunks[0]);
            activeChunks.RemoveAt(0);
        }

        while (nextRowZ < pz + RowSpawnAhead) SpawnRow(nextRowZ);

        float behind = pz - 14f;
        for (int i = activeObstacles.Count - 1; i >= 0; i--)
            if (activeObstacles[i].transform.position.z < behind) ReleaseObstacleAt(i);
        for (int i = activeCoins.Count - 1; i >= 0; i--)
            if (activeCoins[i].transform.position.z < behind) ReleaseCoinAt(i);
    }

    // ================================================================= chunks
    void AddChunk()
    {
        Chunk c = freeChunks.Count > 0 ? freeChunks.Pop() : BuildChunk();
        PlaceChunk(c, nextChunkIndex);
        activeChunks.Add(c);
        nextChunkIndex++;
    }

    void RecycleChunk(Chunk c)
    {
        c.Root.gameObject.SetActive(false);
        freeChunks.Push(c);
    }

    Chunk BuildChunk()
    {
        Chunk c = new Chunk();
        GameObject root = new GameObject("Chunk");
        root.transform.SetParent(chunkRoot, false);
        c.Root = root.transform;
        float half = ChunkLength * 0.5f;

        GameObject grass = PF.Prim("Grass", PrimitiveType.Cube, grassA, c.Root, new Vector3(0f, -0.5f, half), new Vector3(500f, 1f, ChunkLength + 0.02f));
        c.Grass = grass.GetComponent<Renderer>();
        c.Grass.shadowCastingMode = ShadowCastingMode.Off;
        GameObject path = PF.Prim("Path", PrimitiveType.Cube, pathMat, c.Root, new Vector3(0f, -0.03f, half), new Vector3(7.4f, 0.1f, ChunkLength + 0.02f));
        path.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
        GameObject eL = PF.Prim("EdgeL", PrimitiveType.Cube, edgeMat, c.Root, new Vector3(-3.9f, -0.02f, half), new Vector3(0.8f, 0.1f, ChunkLength + 0.02f));
        GameObject eR = PF.Prim("EdgeR", PrimitiveType.Cube, edgeMat, c.Root, new Vector3(3.9f, -0.02f, half), new Vector3(0.8f, 0.1f, ChunkLength + 0.02f));
        eL.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
        eR.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;

        AddDecor(c, DecorKind.Pine, 9);
        AddDecor(c, DecorKind.Round, 3);
        AddDecor(c, DecorKind.Bush, 6);
        AddDecor(c, DecorKind.Rock, 4);
        AddDecor(c, DecorKind.Flower, 12);
        AddDecor(c, DecorKind.Log, 2);
        AddDecor(c, DecorKind.Mushroom, 3);
        AddDecor(c, DecorKind.Hill, 2);
        AddDecor(c, DecorKind.Mountain, 2);

        root.SetActive(false);
        return c;
    }

    void AddDecor(Chunk c, DecorKind kind, int count)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject g;
            switch (kind)
            {
                case DecorKind.Pine: g = PF.BuildPine(c.Root, i); break;
                case DecorKind.Round: g = PF.BuildRoundTree(c.Root, i); break;
                case DecorKind.Bush: g = PF.BuildBush(c.Root); break;
                case DecorKind.Rock: g = PF.BuildRockDecor(c.Root); break;
                case DecorKind.Flower: g = PF.BuildFlower(c.Root, i); break;
                case DecorKind.Log: g = PF.BuildLogDecor(c.Root); break;
                case DecorKind.Mushroom: g = PF.BuildMushroom(c.Root, i); break;
                case DecorKind.Hill: g = PF.BuildHill(c.Root); break;
                default: g = PF.BuildMountain(c.Root); break;
            }
            DecorItem d = new DecorItem();
            d.T = g.transform; d.Kind = kind;
            c.Decor.Add(d);
        }
    }

    void PlaceChunk(Chunk c, int index)
    {
        float z0 = index * ChunkLength;
        c.Root.position = new Vector3(0f, 0f, z0);
        c.EndZ = z0 + ChunkLength;
        c.Grass.sharedMaterial = (index & 1) == 0 ? grassA : grassB;
        c.Root.gameObject.SetActive(true);
        for (int i = 0; i < c.Decor.Count; i++) PlaceDecor(c.Decor[i]);
    }

    void PlaceDecor(DecorItem d)
    {
        float side = Random.value < 0.5f ? -1f : 1f;
        float z = Random.Range(0f, ChunkLength);
        Transform t = d.T;
        Quaternion spin = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
        switch (d.Kind)
        {
            case DecorKind.Pine:
                t.localPosition = new Vector3(side * Random.Range(5.5f, 45f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.8f, 1.6f); t.localRotation = spin; break;
            case DecorKind.Round:
                t.localPosition = new Vector3(side * Random.Range(6.5f, 40f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.8f, 1.3f); t.localRotation = spin; break;
            case DecorKind.Bush:
                t.localPosition = new Vector3(side * Random.Range(4.7f, 24f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.7f, 1.4f); t.localRotation = spin; break;
            case DecorKind.Rock:
                t.localPosition = new Vector3(side * Random.Range(4.6f, 30f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.6f, 1.8f); t.localRotation = spin; break;
            case DecorKind.Flower:
                t.localPosition = new Vector3(side * Random.Range(4.3f, 16f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.9f, 1.5f); t.localRotation = spin; break;
            case DecorKind.Log:
                t.localPosition = new Vector3(side * Random.Range(5.2f, 20f), 0f, z);
                t.localScale = Vector3.one; t.localRotation = spin; break;
            case DecorKind.Mushroom:
                t.localPosition = new Vector3(side * Random.Range(4.6f, 14f), 0f, z);
                t.localScale = Vector3.one * Random.Range(0.8f, 1.6f); t.localRotation = spin; break;
            case DecorKind.Hill:
                t.localPosition = new Vector3(side * Random.Range(60f, 82f), -3f, z);
                t.localScale = new Vector3(Random.Range(36f, 50f), Random.Range(10f, 16f), Random.Range(36f, 50f));
                t.localRotation = Quaternion.identity; break;
            default: // Mountain
                t.localPosition = new Vector3(side * Random.Range(110f, 170f), -2f, z);
                t.localScale = new Vector3(Random.Range(90f, 140f), Random.Range(55f, 95f), Random.Range(90f, 140f));
                t.localRotation = Quaternion.identity; break;
        }
    }

    // ================================================================= obstacle rows + coins
    void SpawnRow(float z)
    {
        float difficulty = Mathf.Clamp01(z / 2500f);
        int mask = 0;
        int lowLane = -1;

        if (z >= FirstObstacleZ)
        {
            int first = Random.Range(0, 3);
            mask = 1 << first;
            // never more than 2 lanes -> at least one lane is always free
            if (Random.value < 0.2f + 0.45f * difficulty) mask |= 1 << ((first + Random.Range(1, 3)) % 3);

            for (int lane = 0; lane < 3; lane++)
            {
                if ((mask & (1 << lane)) == 0) continue;
                ObstacleType type = PickType(z);
                PlaceObstacle(type, lane, z);
                if (type == ObstacleType.Rock || type == ObstacleType.Log || type == ObstacleType.Fence) lowLane = lane;
            }
        }

        SpawnCoins(prevRowZ, z, mask, lowLane);
        prevRowZ = z;

        float speed = GameManager.SpeedAtDistance(z);
        float gapSeconds = Mathf.Lerp(1.55f, 0.9f, difficulty) + Random.Range(0f, 0.45f);
        nextRowZ = z + Mathf.Max(13f, speed * gapSeconds);
    }

    ObstacleType PickType(float z)
    {
        float rock = 25f, log = 20f, fence = 20f;
        float trunk = z > 120f ? 14f : 0f;
        float over = z > 50f ? 22f : 0f;
        float r = Random.value * (rock + log + fence + trunk + over);
        if ((r -= rock) < 0f) return ObstacleType.Rock;
        if ((r -= log) < 0f) return ObstacleType.Log;
        if ((r -= fence) < 0f) return ObstacleType.Fence;
        if ((r -= trunk) < 0f) return ObstacleType.TreeTrunk;
        return ObstacleType.Overhead;
    }

    void SpawnCoins(float prevZ, float z, int mask, int lowLane)
    {
        // Arc of coins above a low obstacle: rewards jumping.
        if (lowLane >= 0 && Random.value < 0.45f)
        {
            for (int i = 0; i < 7; i++)
            {
                float t = i / 6f * 2f - 1f;
                PlaceCoin(LaneX(lowLane), 1.25f + (1f - t * t) * 1.0f, z + t * 3.4f);
            }
            return;
        }

        float start = prevZ + 5f, end = z - 5f;
        if (end - start < 6f || Random.value < 0.15f) return;
        int count = Mathf.Min(12, Mathf.FloorToInt((end - start) / 1.7f) + 1);

        List<int> free = new List<int>(3);
        for (int lane = 0; lane < 3; lane++) if ((mask & (1 << lane)) == 0) free.Add(lane);

        // zig-zag between two neighbouring free lanes
        int pairStart = -1;
        for (int lane = 0; lane < 2; lane++)
            if ((mask & (1 << lane)) == 0 && (mask & (1 << (lane + 1))) == 0) { pairStart = lane; break; }

        if (pairStart >= 0 && Random.value < 0.35f)
        {
            float xa = LaneX(pairStart), xb = LaneX(pairStart + 1);
            for (int i = 0; i < count; i++)
                PlaceCoin(Mathf.Lerp(xa, xb, 0.5f + 0.5f * Mathf.Sin(i * 0.9f)), 0.9f, start + i * 1.7f);
        }
        else
        {
            int lane = free[Random.Range(0, free.Count)];
            for (int i = 0; i < count; i++) PlaceCoin(LaneX(lane), 0.9f, start + i * 1.7f);
        }
    }

    // ================================================================= pools
    void PlaceObstacle(ObstacleType type, int lane, float z)
    {
        int ti = (int)type;
        Obstacle o = freeObstacles[ti].Count > 0 ? freeObstacles[ti].Pop() : BuildObstacle(type);
        o.transform.position = new Vector3(LaneX(lane), 0f, z);
        bool spin = type == ObstacleType.Rock || type == ObstacleType.TreeTrunk;
        o.transform.rotation = spin ? Quaternion.Euler(0f, Random.Range(0f, 360f), 0f) : Quaternion.identity;
        o.gameObject.SetActive(true);
        activeObstacles.Add(o);
    }

    void ReleaseObstacleAt(int index)
    {
        Obstacle o = activeObstacles[index];
        activeObstacles.RemoveAt(index);
        o.gameObject.SetActive(false);
        freeObstacles[(int)o.Type].Push(o);
    }

    void PlaceCoin(float x, float y, float z)
    {
        Coin c = freeCoins.Count > 0 ? freeCoins.Pop() : BuildCoin();
        c.transform.position = new Vector3(x, y, z);
        c.gameObject.SetActive(true);
        activeCoins.Add(c);
    }

    public void ReleaseCoin(Coin c)
    {
        int i = activeCoins.IndexOf(c);
        if (i >= 0) ReleaseCoinAt(i);
    }

    void ReleaseCoinAt(int index)
    {
        Coin c = activeCoins[index];
        activeCoins.RemoveAt(index);
        c.gameObject.SetActive(false);
        freeCoins.Push(c);
    }

    Coin BuildCoin()
    {
        GameObject go = new GameObject("Coin");
        go.transform.SetParent(coinRoot, false);
        SphereCollider sc = go.AddComponent<SphereCollider>();
        sc.isTrigger = true; sc.radius = 0.6f;
        Coin coin = go.AddComponent<Coin>();
        PF.Prim("Disc", PrimitiveType.Cylinder, PF.GoldMat(), go.transform, Vector3.zero, new Vector3(0.62f, 0.07f, 0.62f), new Vector3(90f, 0f, 0f));
        PF.Prim("Emboss", PrimitiveType.Cylinder, PF.Mat("GoldDark", "#E0A000", 0.6f, 0.3f), go.transform, Vector3.zero, new Vector3(0.45f, 0.09f, 0.45f), new Vector3(90f, 0f, 0f));
        go.SetActive(false);
        return coin;
    }

    // ================================================================= obstacle models
    Obstacle BuildObstacle(ObstacleType type)
    {
        GameObject go = new GameObject(type.ToString());
        go.transform.SetParent(obstacleRoot, false);
        Obstacle ob = go.AddComponent<Obstacle>();
        ob.Type = type;
        BoxCollider box = go.AddComponent<BoxCollider>();
        box.isTrigger = true;
        Transform t = go.transform;

        Material rock = PF.Mat("Rock", "#8A8F8C");
        Material rockDark = PF.Mat("RockDark", "#6E7370");
        Material wood = PF.Mat("Wood", "#8B5A2B");
        Material woodLight = PF.Mat("WoodLight", "#C69C6D");
        Material bark = PF.Mat("Bark", "#5B3A22");
        Material moss = PF.Mat("Moss", "#4E8F3A");

        switch (type)
        {
            case ObstacleType.Rock:
                PF.Part("Rock", PF.RockMesh(), rock, t, Vector3.zero, new Vector3(1.35f, 1.3f, 1.35f), Vector3.zero);
                PF.Part("Pebble", PF.RockMesh(), rockDark, t, new Vector3(0.55f, 0f, -0.5f), new Vector3(0.7f, 0.7f, 0.7f), new Vector3(0f, 30f, 0f));
                box.center = new Vector3(0f, 0.4f, 0f); box.size = new Vector3(1.5f, 0.8f, 1.3f);
                break;
            case ObstacleType.Log:
                PF.Prim("Trunk", PrimitiveType.Cylinder, bark, t, new Vector3(0f, 0.45f, 0f), new Vector3(0.45f, 1.0f, 0.45f), new Vector3(0f, 0f, 90f));
                PF.Prim("CapL", PrimitiveType.Cylinder, woodLight, t, new Vector3(-1.0f, 0.45f, 0f), new Vector3(0.38f, 0.02f, 0.38f), new Vector3(0f, 0f, 90f));
                PF.Prim("CapR", PrimitiveType.Cylinder, woodLight, t, new Vector3(1.0f, 0.45f, 0f), new Vector3(0.38f, 0.02f, 0.38f), new Vector3(0f, 0f, 90f));
                PF.Prim("Moss", PrimitiveType.Sphere, moss, t, new Vector3(0.3f, 0.85f, 0f), new Vector3(0.7f, 0.2f, 0.5f));
                box.center = new Vector3(0f, 0.45f, 0f); box.size = new Vector3(2.0f, 0.85f, 0.85f);
                break;
            case ObstacleType.Fence:
                for (int i = -1; i <= 1; i++)
                    PF.Prim("Post", PrimitiveType.Cube, wood, t, new Vector3(i * 0.9f, 0.5f, 0f), new Vector3(0.14f, 1.0f, 0.14f));
                PF.Prim("RailLow", PrimitiveType.Cube, woodLight, t, new Vector3(0f, 0.35f, 0f), new Vector3(2.0f, 0.12f, 0.08f));
                PF.Prim("RailHigh", PrimitiveType.Cube, woodLight, t, new Vector3(0f, 0.75f, 0f), new Vector3(2.0f, 0.12f, 0.08f));
                box.center = new Vector3(0f, 0.5f, 0f); box.size = new Vector3(2.0f, 1.0f, 0.3f);
                break;
            case ObstacleType.TreeTrunk:
                PF.Prim("Trunk", PrimitiveType.Cylinder, bark, t, new Vector3(0f, 2.5f, 0f), new Vector3(1.1f, 2.5f, 1.1f));
                PF.Prim("Moss", PrimitiveType.Sphere, moss, t, new Vector3(0.3f, 1.0f, 0.3f), new Vector3(0.9f, 0.5f, 0.9f));
                PF.Prim("Cap", PrimitiveType.Cylinder, woodLight, t, new Vector3(0f, 5.0f, 0f), new Vector3(0.95f, 0.03f, 0.95f));
                box.center = new Vector3(0f, 2.5f, 0f); box.size = new Vector3(1.1f, 5f, 1.1f);
                break;
            default: // Overhead: duck under the beam
                PF.Prim("PostL", PrimitiveType.Cylinder, wood, t, new Vector3(-1.0f, 1.0f, 0f), new Vector3(0.24f, 1.0f, 0.24f));
                PF.Prim("PostR", PrimitiveType.Cylinder, wood, t, new Vector3(1.0f, 1.0f, 0f), new Vector3(0.24f, 1.0f, 0.24f));
                PF.Prim("Beam", PrimitiveType.Cylinder, bark, t, new Vector3(0f, 1.2f, 0f), new Vector3(0.5f, 1.05f, 0.5f), new Vector3(0f, 0f, 90f));
                PF.Prim("LeavesA", PrimitiveType.Sphere, moss, t, new Vector3(-0.5f, 1.5f, 0f), new Vector3(0.8f, 0.45f, 0.6f));
                PF.Prim("LeavesB", PrimitiveType.Sphere, moss, t, new Vector3(0.5f, 1.45f, 0f), new Vector3(0.7f, 0.4f, 0.55f));
                box.center = new Vector3(0f, 1.2f, 0f); box.size = new Vector3(2.1f, 0.55f, 0.5f);
                break;
        }
        go.SetActive(false);
        return ob;
    }
}
