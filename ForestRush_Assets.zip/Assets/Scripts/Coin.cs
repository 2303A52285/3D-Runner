using UnityEngine;

/// <summary>A spinning gold coin. The player's collider triggers Collect().</summary>
public class Coin : MonoBehaviour
{
    void Update()
    {
        transform.Rotate(0f, 220f * Time.deltaTime, 0f, Space.World);
    }

    public void Collect()
    {
        GameManager gm = GameManager.Instance;
        if (gm == null) return;
        gm.AddCoin();
        if (Effects.Instance != null)
            Effects.Instance.Burst(transform.position, Effects.GoldMaterial, 8, 3.5f, 0.16f, 0.45f);
        if (AudioManager.Instance != null) AudioManager.Instance.PlayCoin();
        gm.Level.ReleaseCoin(this);
    }
}
