using System.Collections;
using UnityEngine;

public enum GameState { Menu, Playing, Paused, GameOver }

/// <summary>Owns the game state, score, coins, saving and the hotkeys (Esc / R / Enter).</summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public const float BaseSpeed = 14f;
    public const float MaxSpeed = 34f;
    const float SpeedGainPerMeter = 0.0125f;

    const string KeyBest = "FR_BestScore";
    const string KeyCoins = "FR_TotalCoins";
    const string KeySens = "FR_Sensitivity";

    public GameState State { get; private set; }
    public PlayerController Player { get; private set; }
    public LevelGenerator Level { get; private set; }
    public CameraFollow Cam { get; private set; }
    public UIManager UI { get; private set; }

    public float Speed { get; private set; }
    public float Distance { get; private set; }
    public int Score { get; private set; }
    public int RunCoins { get; private set; }
    public int TotalCoins { get; private set; }
    public int BestScore { get; private set; }
    public int SensitivityLevel { get; private set; }   // 0 low, 1 medium, 2 high

    public float SwipeSensitivity
    {
        get { return SensitivityLevel == 0 ? 0.7f : (SensitivityLevel == 1 ? 1f : 1.5f); }
    }

    public static float SpeedAtDistance(float d)
    {
        return Mathf.Min(MaxSpeed, BaseSpeed + d * SpeedGainPerMeter);
    }

    void Awake() { Instance = this; }

    public void Init(PlayerController player, LevelGenerator level, CameraFollow cam, UIManager ui)
    {
        Player = player; Level = level; Cam = cam; UI = ui;
        BestScore = PlayerPrefs.GetInt(KeyBest, 0);
        TotalCoins = PlayerPrefs.GetInt(KeyCoins, 0);
        SensitivityLevel = PlayerPrefs.GetInt(KeySens, 1);
        Speed = BaseSpeed;
        GoToMenu();
        Cam.Snap();
    }

    void Update()
    {
        HandleHotkeys();
        if (State == GameState.Playing)
        {
            Distance = Player.transform.position.z;
            Speed = SpeedAtDistance(Distance);
            Score = Mathf.FloorToInt(Distance) + RunCoins * 10;
            UI.UpdateHud(Score, RunCoins, TotalCoins, Mathf.FloorToInt(Distance), Mathf.RoundToInt(Speed));
        }
    }

    void HandleHotkeys()
    {
        if (GameInput.PausePressed())
        {
            if (State == GameState.Playing) Pause();
            else if (State == GameState.Paused) Resume();
            else if (State == GameState.GameOver) GoToMenu();
        }
        if (GameInput.RestartPressed() && State != GameState.Menu) StartGame();
        if (GameInput.ConfirmPressed())
        {
            if (State == GameState.Menu || State == GameState.GameOver) StartGame();
        }
    }

    // ------------------------------------------------------------ state changes
    public void GoToMenu()
    {
        StopAllCoroutines();
        Time.timeScale = 1f;
        State = GameState.Menu;
        Player.ResetPlayer();
        Level.ResetWorld();
        Cam.SetMenuMode(true);
        UI.ShowMenu(BestScore, TotalCoins);
    }

    public void StartGame()
    {
        StopAllCoroutines();
        bool fromMenu = State == GameState.Menu;
        Time.timeScale = 1f;
        Player.ResetPlayer();
        Level.ResetWorld();
        Distance = 0f; Score = 0; RunCoins = 0; Speed = BaseSpeed;
        State = GameState.Playing;
        Cam.SetMenuMode(false);
        if (!fromMenu) Cam.Snap();
        UI.ShowHud(BestScore);
        UI.UpdateHud(0, 0, TotalCoins, 0, Mathf.RoundToInt(BaseSpeed));
    }

    public void Pause()
    {
        if (State != GameState.Playing) return;
        State = GameState.Paused;
        Time.timeScale = 0f;
        PlayerPrefs.Save();
        UI.ShowPause();
    }

    public void Resume()
    {
        if (State != GameState.Paused) return;
        Time.timeScale = 1f;
        State = GameState.Playing;
        UI.ShowHud(BestScore);
    }

    public void GameOver()
    {
        if (State != GameState.Playing) return;
        State = GameState.GameOver;
        Player.Die();
        if (AudioManager.Instance != null) AudioManager.Instance.PlayHit();
        if (Effects.Instance != null)
            Effects.Instance.Burst(Player.transform.position + Vector3.up, Effects.HitMaterial, 18, 6f, 0.28f, 0.8f);
        Cam.Shake(0.3f, 0.35f);

        bool newBest = Score > BestScore;
        if (newBest) { BestScore = Score; PlayerPrefs.SetInt(KeyBest, BestScore); }
        PlayerPrefs.SetInt(KeyCoins, TotalCoins);
        PlayerPrefs.Save();
        StartCoroutine(ShowGameOverRoutine(newBest));
    }

    IEnumerator ShowGameOverRoutine(bool newBest)
    {
        yield return new WaitForSecondsRealtime(0.9f);
        if (State == GameState.GameOver) UI.ShowGameOver(Score, BestScore, RunCoins, newBest);
    }

    public void AddCoin()
    {
        RunCoins++;
        TotalCoins++;
        PlayerPrefs.SetInt(KeyCoins, TotalCoins);
    }

    public void CycleSensitivity()
    {
        SensitivityLevel = (SensitivityLevel + 1) % 3;
        PlayerPrefs.SetInt(KeySens, SensitivityLevel);
    }

    void OnApplicationPause(bool paused)
    {
        if (paused) { PlayerPrefs.Save(); if (State == GameState.Playing) Pause(); }
    }

    void OnApplicationQuit() { PlayerPrefs.Save(); }
}
