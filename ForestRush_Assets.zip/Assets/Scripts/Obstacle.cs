using UnityEngine;

public enum ObstacleType { Rock, Log, Fence, TreeTrunk, Overhead }

/// <summary>Marker on every obstacle. Touching one (via the player's collider) = Game Over.</summary>
public class Obstacle : MonoBehaviour
{
    public ObstacleType Type;

    /// <summary>Low obstacles can be jumped over.</summary>
    public bool IsLow
    {
        get { return Type == ObstacleType.Rock || Type == ObstacleType.Log || Type == ObstacleType.Fence; }
    }
}
