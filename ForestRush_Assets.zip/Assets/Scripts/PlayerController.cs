using UnityEngine;

/// <summary>
/// The forest adventurer. Built entirely from primitives, animated with code.
/// Runs forward automatically, 3 lanes, jump, slide. Ground detection is a simple
/// "y never goes below 0", so the player can never fall through the world.
/// </summary>
public class PlayerController : MonoBehaviour
{
    const float Gravity = 45f;
    const float JumpHeight = 2.3f;
    const float FastFallSpeed = 28f;
    const float SlideTime = 0.85f;
    const float LaneChangeSpeed = 17f;
    const float StandHeight = 1.7f;
    const float SlideHeight = 0.7f;

    int lane = 1;
    float targetX, velY, slideTimer, runPhase;
    bool grounded = true, sliding, slideQueued, dead;
    int lastStep;

    BoxCollider box;
    Transform visual, body, head, armL, armR, legL, legR;
    float curLegL, curLegR, curArmL, curArmR, curPitch, curVisY;

    void Awake()
    {
        Rigidbody rb = gameObject.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.useGravity = false;
        box = gameObject.AddComponent<BoxCollider>();
        SetCollider(false);
        BuildModel();
    }

    // ------------------------------------------------------------ model
    static Vector3 V(float x, float y, float z) { return new Vector3(x, y, z); }

    Transform MakeLimb(string name, Transform parent, Vector3 pivotPos, float width, float length, Material mat, Material endMat, bool boot)
    {
        Transform pivot = new GameObject(name).transform;
        pivot.SetParent(parent, false);
        pivot.localPosition = pivotPos;
        ProceduralFactory.Prim("Segment", PrimitiveType.Cube, mat, pivot, V(0f, -length * 0.5f, 0f), V(width, length, width * 1.1f));
        if (boot) ProceduralFactory.Prim("Boot", PrimitiveType.Cube, endMat, pivot, V(0f, -length - 0.04f, 0.05f), V(width * 1.1f, 0.16f, 0.32f));
        else ProceduralFactory.Prim("Hand", PrimitiveType.Sphere, endMat, pivot, V(0f, -length - 0.02f, 0f), V(width * 1.15f, width * 1.15f, width * 1.15f));
        return pivot;
    }

    void BuildModel()
    {
        Material skin = ProceduralFactory.Mat("Skin", "#F2C9A0");
        Material tunic = ProceduralFactory.Mat("Tunic", "#3FA34D");
        Material tunicDark = ProceduralFactory.Mat("TunicDark", "#2E7D3A");
        Material pants = ProceduralFactory.Mat("Pants", "#6B4A2F");
        Material leather = ProceduralFactory.Mat("Leather", "#4A3020");
        Material hat = ProceduralFactory.Mat("Hat", "#C0502F");
        Material feather = ProceduralFactory.Mat("Feather", "#FFD54A");
        Material eye = ProceduralFactory.Mat("Eye", "#222222");

        visual = new GameObject("Visual").transform;
        visual.SetParent(transform, false);
        body = new GameObject("Body").transform;
        body.SetParent(visual, false);

        ProceduralFactory.Prim("Torso", PrimitiveType.Cube, tunic, body, V(0f, 1.05f, 0f), V(0.55f, 0.62f, 0.34f));
        ProceduralFactory.Prim("Belt", PrimitiveType.Cube, leather, body, V(0f, 0.8f, 0f), V(0.58f, 0.09f, 0.37f));
        ProceduralFactory.Prim("Backpack", PrimitiveType.Cube, leather, body, V(0f, 1.05f, -0.27f), V(0.42f, 0.46f, 0.2f));
        ProceduralFactory.Prim("Scarf", PrimitiveType.Cube, hat, body, V(0f, 1.37f, 0f), V(0.4f, 0.1f, 0.4f));

        head = new GameObject("Head").transform;
        head.SetParent(body, false);
        head.localPosition = V(0f, 1.45f, 0f);
        ProceduralFactory.Prim("Skull", PrimitiveType.Sphere, skin, head, V(0f, 0.14f, 0f), V(0.44f, 0.44f, 0.44f));
        ProceduralFactory.Prim("EyeL", PrimitiveType.Sphere, eye, head, V(-0.1f, 0.17f, 0.19f), V(0.07f, 0.07f, 0.05f));
        ProceduralFactory.Prim("EyeR", PrimitiveType.Sphere, eye, head, V(0.1f, 0.17f, 0.19f), V(0.07f, 0.07f, 0.05f));
        ProceduralFactory.Prim("HatBrim", PrimitiveType.Cylinder, hat, head, V(0f, 0.27f, 0f), V(0.66f, 0.02f, 0.66f));
        ProceduralFactory.Part("HatCone", ProceduralFactory.ConeMesh(), hat, head, V(0f, 0.27f, 0f), V(0.42f, 0.42f, 0.42f), Vector3.zero);
        ProceduralFactory.Prim("Feather", PrimitiveType.Cube, feather, head, V(0.17f, 0.45f, -0.02f), V(0.04f, 0.22f, 0.09f), V(0f, 0f, -25f));

        armL = MakeLimb("ArmL", body, V(-0.36f, 1.32f, 0f), 0.16f, 0.5f, tunicDark, skin, false);
        armR = MakeLimb("ArmR", body, V(0.36f, 1.32f, 0f), 0.16f, 0.5f, tunicDark, skin, false);
        legL = MakeLimb("LegL", body, V(-0.14f, 0.78f, 0f), 0.2f, 0.62f, pants, leather, true);
        legR = MakeLimb("LegR", body, V(0.14f, 0.78f, 0f), 0.2f, 0.62f, pants, leather, true);
    }

    void SetCollider(bool slide)
    {
        float h = slide ? SlideHeight : StandHeight;
        box.size = new Vector3(0.7f, h, 0.5f);
        box.center = new Vector3(0f, h * 0.5f, 0f);
    }

    // ------------------------------------------------------------ public commands
    bool CanAct()
    {
        GameManager gm = GameManager.Instance;
        return gm != null && gm.State == GameState.Playing && !dead;
    }

    public void MoveLeft() { if (!CanAct()) return; lane = Mathf.Max(0, lane - 1); targetX = (lane - 1) * LevelGenerator.LaneWidth; }
    public void MoveRight() { if (!CanAct()) return; lane = Mathf.Min(2, lane + 1); targetX = (lane - 1) * LevelGenerator.LaneWidth; }

    public void Jump()
    {
        if (!CanAct() || !grounded) return;
        EndSlide();
        velY = Mathf.Sqrt(2f * Gravity * JumpHeight);
        grounded = false;
        if (AudioManager.Instance != null) AudioManager.Instance.PlayJump();
    }

    public void Slide()
    {
        if (!CanAct()) return;
        if (grounded) { if (!sliding) StartSlide(); }
        else { slideQueued = true; velY = Mathf.Min(velY, -FastFallSpeed); }
    }

    void StartSlide()
    {
        sliding = true; slideTimer = SlideTime; SetCollider(true);
        if (AudioManager.Instance != null) AudioManager.Instance.PlaySlide();
    }

    void EndSlide() { sliding = false; slideQueued = false; SetCollider(false); }

    public void Die() { dead = true; EndSlide(); }

    public void ResetPlayer()
    {
        transform.position = Vector3.zero;
        lane = 1; targetX = 0f; velY = 0f; runPhase = 0f; lastStep = 0;
        grounded = true; dead = false;
        EndSlide();
        curLegL = curLegR = curArmL = curArmR = curPitch = curVisY = 0f;
        if (visual != null) { visual.localRotation = Quaternion.identity; visual.localPosition = Vector3.zero; }
    }

    // ------------------------------------------------------------ update
    void Update()
    {
        GameManager gm = GameManager.Instance;
        if (gm == null) return;
        float dt = Time.deltaTime;

        if (gm.State == GameState.Playing && !dead)
        {
            ReadKeyboard();
            float speed = gm.Speed;
            Vector3 p = transform.position;
            p.z += speed * dt;
            p.x = Mathf.MoveTowards(p.x, targetX, LaneChangeSpeed * dt);
            transform.position = p;
            ApplyVertical(dt);
            if (sliding) { slideTimer -= dt; if (slideTimer <= 0f) EndSlide(); }

            runPhase += speed * dt * 0.7f;
            int stepIndex = Mathf.FloorToInt(runPhase / Mathf.PI);
            if (stepIndex != lastStep)
            {
                lastStep = stepIndex;
                if (grounded && !sliding && AudioManager.Instance != null) AudioManager.Instance.PlayStep();
            }
        }
        else if (dead)
        {
            ApplyVertical(dt);
        }
        Animate(dt, gm.State);
    }

    void ReadKeyboard()
    {
        if (GameInput.LeftPressed()) MoveLeft();
        if (GameInput.RightPressed()) MoveRight();
        if (GameInput.JumpPressed()) Jump();
        if (GameInput.SlidePressed()) Slide();
    }

    void ApplyVertical(float dt)
    {
        if (grounded) return;
        velY -= Gravity * dt;
        Vector3 p = transform.position;
        p.y += velY * dt;
        if (p.y <= 0f)
        {
            p.y = 0f; velY = 0f; grounded = true;
            transform.position = p;
            OnLanded();
            return;
        }
        transform.position = p;
    }

    void OnLanded()
    {
        if (Effects.Instance != null && !dead)
            Effects.Instance.Burst(transform.position + Vector3.up * 0.05f, Effects.DustMaterial, 6, 1.8f, 0.14f, 0.4f);
        if (slideQueued && !dead) { slideQueued = false; StartSlide(); }
    }

    void Animate(float dt, GameState state)
    {
        float tLegL = 0f, tLegR = 0f, tArmL = 0f, tArmR = 0f, bob = 0f, pitch = 0f, lean = 0f, visY = 0f;

        if (dead)
        {
            pitch = -85f; visY = 0.28f; tArmL = -40f; tArmR = 40f; tLegL = 20f; tLegR = -10f;
        }
        else if (state == GameState.Playing || state == GameState.Paused)
        {
            if (sliding) { pitch = -78f; visY = 0.3f; tLegL = -15f; tLegR = -5f; tArmL = 40f; tArmR = 40f; }
            else if (!grounded) { tLegL = 40f; tLegR = -35f; tArmL = -150f; tArmR = -150f; }
            else
            {
                float s = Mathf.Sin(runPhase);
                tLegL = s * 55f; tLegR = -s * 55f; tArmL = -s * 50f; tArmR = s * 50f;
                bob = Mathf.Abs(Mathf.Cos(runPhase)) * 0.07f;
                pitch = 8f;
            }
            lean = -Mathf.Clamp(targetX - transform.position.x, -1f, 1f) * 14f;
        }
        else
        {
            float s = Mathf.Sin(Time.time * 2f);
            tArmL = s * 6f; tArmR = -s * 6f;
            bob = (s * 0.5f + 0.5f) * 0.02f;
        }

        float k = 1f - Mathf.Exp(-22f * dt);
        curLegL = Mathf.Lerp(curLegL, tLegL, k);
        curLegR = Mathf.Lerp(curLegR, tLegR, k);
        curArmL = Mathf.Lerp(curArmL, tArmL, k);
        curArmR = Mathf.Lerp(curArmR, tArmR, k);
        curPitch = Mathf.Lerp(curPitch, pitch, k);
        curVisY = Mathf.Lerp(curVisY, visY, k);

        legL.localRotation = Quaternion.Euler(curLegL, 0f, 0f);
        legR.localRotation = Quaternion.Euler(curLegR, 0f, 0f);
        armL.localRotation = Quaternion.Euler(curArmL, 0f, 0f);
        armR.localRotation = Quaternion.Euler(curArmR, 0f, 0f);
        visual.localRotation = Quaternion.Euler(curPitch, 0f, lean);
        visual.localPosition = new Vector3(0f, curVisY, 0f);
        body.localPosition = new Vector3(0f, bob, 0f);
    }

    // ------------------------------------------------------------ collisions
    void OnTriggerEnter(Collider other)
    {
        GameManager gm = GameManager.Instance;
        if (gm == null || gm.State != GameState.Playing || dead) return;

        Coin coin = other.GetComponent<Coin>();
        if (coin != null) { coin.Collect(); return; }

        if (other.GetComponentInParent<Obstacle>() != null) gm.GameOver();
    }
}
