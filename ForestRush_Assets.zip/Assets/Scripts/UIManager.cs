using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Builds the whole interface in code (main menu, settings, HUD, pause, game over, touch buttons).
/// Uses Unity's built-in UI Text and a built-in font, so there are no missing fonts or TMP imports.
/// </summary>
public class UIManager : MonoBehaviour
{
    GameManager gm;
    Canvas canvas;
    Font font;
    Sprite rounded, coinIcon;

    GameObject menuPanel, settingsPanel, hudPanel, pausePanel, overPanel, touchPanel;
    Text hudScore, hudBest, hudDist, hudCoins, hudTotal, hudSpeed;
    Text menuBest, menuCoins, overScore, overBest, overCoins, overTitle;
    Text menuSoundLabel, soundLabel, musicLabel, sensLabel;
    int cScore = -1, cCoins = -1, cTotal = -1, cDist = -1, cSpeed = -1;

    static readonly Color Dark = new Color(0.03f, 0.14f, 0.07f, 0.72f);
    static readonly Color Green = new Color(0.25f, 0.65f, 0.28f, 1f);
    static readonly Color Brown = new Color(0.55f, 0.36f, 0.18f, 1f);
    static readonly Color Red = new Color(0.8f, 0.28f, 0.22f, 1f);
    static readonly Color Gold = new Color(1f, 0.82f, 0.25f, 1f);

    // ================================================================= build
    public void Build(GameManager manager)
    {
        gm = manager;
#if UNITY_2022_2_OR_NEWER
        font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 16);
        rounded = ProceduralFactory.RoundedSprite();
        coinIcon = ProceduralFactory.CoinSprite();

        EnsureEventSystem();

        GameObject cgo = new GameObject("Canvas");
        canvas = cgo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        CanvasScaler scaler = cgo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        cgo.AddComponent<GraphicRaycaster>();

        BuildMenu();
        BuildSettings();
        BuildHud();
        BuildPause();
        BuildGameOver();
        BuildTouchControls();
        HideAll();
    }

    static T FindOne<T>() where T : Object
    {
#if UNITY_2023_1_OR_NEWER
        return Object.FindFirstObjectByType<T>();
#else
        return Object.FindObjectOfType<T>();
#endif
    }

    void EnsureEventSystem()
    {
        if (FindOne<EventSystem>() != null) return;
        GameObject go = new GameObject("EventSystem");
        go.AddComponent<EventSystem>();
#if ENABLE_LEGACY_INPUT_MANAGER
        go.AddComponent<StandaloneInputModule>();
#elif ENABLE_INPUT_SYSTEM
        UnityEngine.InputSystem.UI.InputSystemUIInputModule module = go.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
        module.AssignDefaultActions();
#endif
    }

    // ================================================================= helpers
    RectTransform NewRect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        rt.anchorMin = anchor; rt.anchorMax = anchor; rt.pivot = anchor;
        rt.anchoredPosition = pos; rt.sizeDelta = size;
        return rt;
    }

    RectTransform FullScreen(string name, Transform parent, Color color, bool blocks)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        Image img = go.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = blocks;
        return rt;
    }

    Image Card(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color)
    {
        RectTransform rt = NewRect(name, parent, anchor, pos, size);
        Image img = rt.gameObject.AddComponent<Image>();
        img.sprite = rounded; img.type = Image.Type.Sliced; img.color = color;
        img.raycastTarget = false;
        return img;
    }

    Text MakeText(Transform parent, string name, string content, int size, Color color, TextAnchor align, Vector2 anchor, Vector2 pos, Vector2 box)
    {
        RectTransform rt = NewRect(name, parent, anchor, pos, box);
        Text t = rt.gameObject.AddComponent<Text>();
        t.font = font; t.text = content; t.fontSize = size; t.color = color; t.alignment = align;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.fontStyle = FontStyle.Bold;
        t.raycastTarget = false;
        Outline o = rt.gameObject.AddComponent<Outline>();
        o.effectColor = new Color(0f, 0f, 0f, 0.65f);
        o.effectDistance = new Vector2(3f, -3f);
        return t;
    }

    Image MakeIcon(Transform parent, Vector2 anchor, Vector2 pos, float size)
    {
        RectTransform rt = NewRect("CoinIcon", parent, anchor, pos, new Vector2(size, size));
        Image img = rt.gameObject.AddComponent<Image>();
        img.sprite = coinIcon; img.raycastTarget = false;
        return img;
    }

    void Click()
    {
        if (AudioManager.Instance != null) AudioManager.Instance.PlayClick();
        if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
    }

    Button MakeButton(Transform parent, string name, string label, Vector2 anchor, Vector2 pos, Vector2 size, Color color, int fontSize, UnityAction onClick)
    {
        RectTransform rt = NewRect(name, parent, anchor, pos, size);
        Image img = rt.gameObject.AddComponent<Image>();
        img.sprite = rounded; img.type = Image.Type.Sliced; img.color = color;
        Button b = rt.gameObject.AddComponent<Button>();
        b.targetGraphic = img;
        Navigation nav = new Navigation();
        nav.mode = Navigation.Mode.None;
        b.navigation = nav;
        MakeText(rt, "Label", label, fontSize, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, size);
        b.onClick.AddListener(() => { Click(); onClick(); });
        return b;
    }

    static Text LabelOf(Button b) { return b.GetComponentInChildren<Text>(); }

    // ================================================================= panels
    void BuildMenu()
    {
        RectTransform root = FullScreen("MainMenu", canvas.transform, new Color(0.02f, 0.12f, 0.05f, 0.18f), true);
        menuPanel = root.gameObject;

        Card("TitleCard", root, new Vector2(0.5f, 1f), new Vector2(0f, -60f), new Vector2(1000f, 330f), Dark);
        MakeText(root, "Title", "FOREST RUSH", 130, new Color(0.78f, 1f, 0.55f), TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -150f), new Vector2(1000f, 150f));
        MakeText(root, "Subtitle", "ENDLESS ADVENTURE", 54, Gold, TextAnchor.MiddleCenter, new Vector2(0.5f, 1f), new Vector2(0f, -290f), new Vector2(1000f, 70f));

        MakeButton(root, "Play", "PLAY", new Vector2(0.5f, 0.5f), new Vector2(0f, 40f), new Vector2(480f, 130f), Green, 70, () => gm.StartGame());
        MakeButton(root, "Settings", "SETTINGS", new Vector2(0.5f, 0.5f), new Vector2(0f, -110f), new Vector2(480f, 100f), Brown, 48, ShowSettings);

        Card("StatsCard", root, new Vector2(0.5f, 0f), new Vector2(0f, 150f), new Vector2(760f, 110f), Dark);
        menuBest = MakeText(root, "Best", "BEST  0", 52, Color.white, TextAnchor.MiddleLeft, new Vector2(0.5f, 0f), new Vector2(-170f, 160f), new Vector2(360f, 90f));
        MakeIcon(root, new Vector2(0.5f, 0f), new Vector2(60f, 170f), 70f);
        menuCoins = MakeText(root, "Coins", "0", 56, Gold, TextAnchor.MiddleLeft, new Vector2(0.5f, 0f), new Vector2(240f, 160f), new Vector2(260f, 90f));

        MakeText(root, "Hint", "A/D or ARROWS: move   SPACE: jump   S/DOWN: slide   ESC: pause   R: restart", 34, Color.white,
            TextAnchor.MiddleCenter, new Vector2(0.5f, 0f), new Vector2(0f, 30f), new Vector2(1300f, 50f));

        Button snd = MakeButton(root, "SoundToggle", "SOUND: ON", new Vector2(1f, 0f), new Vector2(-40f, 40f), new Vector2(300f, 90f), Brown, 38, ToggleSound);
        menuSoundLabel = LabelOf(snd);
    }

    void BuildSettings()
    {
        RectTransform root = FullScreen("Settings", canvas.transform, new Color(0f, 0f, 0f, 0.6f), true);
        settingsPanel = root.gameObject;
        Card("Card", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(900f, 760f), Dark);
        MakeText(root, "Title", "SETTINGS", 90, Gold, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, 290f), new Vector2(800f, 110f));

        Button snd = MakeButton(root, "Sound", "", new Vector2(0.5f, 0.5f), new Vector2(0f, 130f), new Vector2(640f, 100f), Green, 44, ToggleSound);
        soundLabel = LabelOf(snd);
        Button mus = MakeButton(root, "Music", "", new Vector2(0.5f, 0.5f), new Vector2(0f, 10f), new Vector2(640f, 100f), Green, 44, ToggleMusic);
        musicLabel = LabelOf(mus);
        Button sens = MakeButton(root, "Sens", "", new Vector2(0.5f, 0.5f), new Vector2(0f, -110f), new Vector2(640f, 100f), Green, 40, CycleSens);
        sensLabel = LabelOf(sens);
        MakeButton(root, "Back", "BACK", new Vector2(0.5f, 0.5f), new Vector2(0f, -270f), new Vector2(400f, 100f), Brown, 48, () => gm.GoToMenu());
    }

    void BuildHud()
    {
        GameObject go = new GameObject("HUD", typeof(RectTransform));
        RectTransform root = go.GetComponent<RectTransform>();
        root.SetParent(canvas.transform, false);
        root.anchorMin = Vector2.zero; root.anchorMax = Vector2.one;
        root.offsetMin = Vector2.zero; root.offsetMax = Vector2.zero;
        hudPanel = go;

        Card("ScoreCard", root, new Vector2(0f, 1f), new Vector2(30f, -30f), new Vector2(470f, 205f), Dark);
        MakeText(root, "ScoreLabel", "SCORE", 30, new Color(0.8f, 1f, 0.7f), TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(54f, -42f), new Vector2(300f, 40f));
        hudScore = MakeText(root, "Score", "0", 84, Color.white, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(54f, -72f), new Vector2(420f, 100f));
        hudDist = MakeText(root, "Dist", "0 m", 34, Color.white, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(54f, -180f), new Vector2(200f, 40f));
        hudBest = MakeText(root, "Best", "BEST 0", 34, Gold, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(250f, -180f), new Vector2(240f, 40f));

        Card("CoinCard", root, new Vector2(1f, 1f), new Vector2(-170f, -30f), new Vector2(400f, 130f), Dark);
        MakeIcon(root, new Vector2(1f, 1f), new Vector2(-495f, -45f), 70f);
        hudCoins = MakeText(root, "RunCoins", "0", 60, Gold, TextAnchor.UpperLeft, new Vector2(1f, 1f), new Vector2(-190f, -38f), new Vector2(290f, 80f));
        hudTotal = MakeText(root, "TotalCoins", "TOTAL 0", 30, Color.white, TextAnchor.UpperLeft, new Vector2(1f, 1f), new Vector2(-190f, -108f), new Vector2(360f, 36f));

        MakeButton(root, "PauseButton", "II", new Vector2(1f, 1f), new Vector2(-30f, -30f), new Vector2(120f, 130f), Brown, 56, () => gm.Pause());

        Card("SpeedCard", root, new Vector2(0f, 0f), new Vector2(30f, 30f), new Vector2(270f, 70f), Dark);
        hudSpeed = MakeText(root, "Speed", "SPEED 14", 36, Color.white, TextAnchor.MiddleLeft, new Vector2(0f, 0f), new Vector2(54f, 30f), new Vector2(240f, 70f));
    }

    void BuildPause()
    {
        RectTransform root = FullScreen("Pause", canvas.transform, new Color(0f, 0f, 0f, 0.55f), true);
        pausePanel = root.gameObject;
        Card("Card", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(700f, 660f), Dark);
        MakeText(root, "Title", "PAUSED", 100, Gold, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, 220f), new Vector2(700f, 120f));
        MakeButton(root, "Resume", "RESUME", new Vector2(0.5f, 0.5f), new Vector2(0f, 60f), new Vector2(500f, 100f), Green, 52, () => gm.Resume());
        MakeButton(root, "Restart", "RESTART", new Vector2(0.5f, 0.5f), new Vector2(0f, -70f), new Vector2(500f, 100f), Brown, 52, () => gm.StartGame());
        MakeButton(root, "Menu", "MAIN MENU", new Vector2(0.5f, 0.5f), new Vector2(0f, -200f), new Vector2(500f, 100f), Red, 52, () => gm.GoToMenu());
    }

    void BuildGameOver()
    {
        RectTransform root = FullScreen("GameOver", canvas.transform, new Color(0.25f, 0f, 0f, 0.5f), true);
        overPanel = root.gameObject;
        Card("Card", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(900f, 760f), Dark);
        overTitle = MakeText(root, "Title", "GAME OVER", 120, new Color(1f, 0.45f, 0.35f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, 280f), new Vector2(880f, 140f));
        overScore = MakeText(root, "Score", "SCORE 0", 76, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, 150f), new Vector2(880f, 100f));
        overBest = MakeText(root, "Best", "BEST 0", 48, Gold, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0f, 60f), new Vector2(880f, 70f));
        MakeIcon(root, new Vector2(0.5f, 0.5f), new Vector2(-170f, -30f), 64f);
        overCoins = MakeText(root, "Coins", "+0", 56, Gold, TextAnchor.MiddleLeft, new Vector2(0.5f, 0.5f), new Vector2(80f, -30f), new Vector2(400f, 80f));
        MakeButton(root, "Again", "PLAY AGAIN", new Vector2(0.5f, 0.5f), new Vector2(0f, -140f), new Vector2(520f, 110f), Green, 56, () => gm.StartGame());
        MakeButton(root, "Menu", "MAIN MENU", new Vector2(0.5f, 0.5f), new Vector2(0f, -270f), new Vector2(520f, 100f), Brown, 50, () => gm.GoToMenu());
    }

    void BuildTouchControls()
    {
        GameObject go = new GameObject("TouchControls", typeof(RectTransform));
        RectTransform root = go.GetComponent<RectTransform>();
        root.SetParent(canvas.transform, false);
        root.anchorMin = Vector2.zero; root.anchorMax = Vector2.one;
        root.offsetMin = Vector2.zero; root.offsetMax = Vector2.zero;
        touchPanel = go;
        Color c = new Color(0f, 0f, 0f, 0.4f);
        TouchButton(root, "<", new Vector2(0f, 0f), new Vector2(40f, 120f), new Vector2(200f, 200f), c, () => gm.Player.MoveLeft());
        TouchButton(root, ">", new Vector2(0f, 0f), new Vector2(270f, 120f), new Vector2(200f, 200f), c, () => gm.Player.MoveRight());
        TouchButton(root, "JUMP", new Vector2(1f, 0f), new Vector2(-40f, 340f), new Vector2(260f, 180f), c, () => gm.Player.Jump());
        TouchButton(root, "SLIDE", new Vector2(1f, 0f), new Vector2(-40f, 130f), new Vector2(260f, 180f), c, () => gm.Player.Slide());
    }

    void TouchButton(Transform parent, string label, Vector2 anchor, Vector2 pos, Vector2 size, Color color, UnityAction action)
    {
        RectTransform rt = NewRect("Touch" + label, parent, anchor, pos, size);
        Image img = rt.gameObject.AddComponent<Image>();
        img.sprite = rounded; img.type = Image.Type.Sliced; img.color = color;
        MakeText(rt, "Label", label, 52, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, size);
        EventTrigger trigger = rt.gameObject.AddComponent<EventTrigger>();
        EventTrigger.Entry entry = new EventTrigger.Entry();
        entry.eventID = EventTriggerType.PointerDown;
        entry.callback.AddListener(e => action());
        trigger.triggers.Add(entry);
    }

    // ================================================================= settings actions
    void ToggleSound() { if (AudioManager.Instance != null) AudioManager.Instance.ToggleSound(); RefreshLabels(); }
    void ToggleMusic() { if (AudioManager.Instance != null) AudioManager.Instance.ToggleMusic(); RefreshLabels(); }
    void CycleSens() { gm.CycleSensitivity(); RefreshLabels(); }

    void RefreshLabels()
    {
        AudioManager a = AudioManager.Instance;
        bool snd = a != null && a.SoundOn;
        bool mus = a != null && a.MusicOn;
        if (menuSoundLabel != null) menuSoundLabel.text = "SOUND: " + (snd ? "ON" : "OFF");
        if (soundLabel != null) soundLabel.text = "SOUND: " + (snd ? "ON" : "OFF");
        if (musicLabel != null) musicLabel.text = "MUSIC: " + (mus ? "ON" : "OFF");
        if (sensLabel != null)
        {
            string[] names = { "LOW", "MEDIUM", "HIGH" };
            sensLabel.text = "SWIPE SENSITIVITY: " + names[gm.SensitivityLevel];
        }
    }

    // ================================================================= show / hide
    void HideAll()
    {
        menuPanel.SetActive(false); settingsPanel.SetActive(false); hudPanel.SetActive(false);
        pausePanel.SetActive(false); overPanel.SetActive(false); touchPanel.SetActive(false);
    }

    public void ShowMenu(int best, int coins)
    {
        HideAll();
        menuPanel.SetActive(true);
        menuBest.text = "BEST  " + best;
        menuCoins.text = coins.ToString();
        RefreshLabels();
    }

    void ShowSettings()
    {
        HideAll();
        settingsPanel.SetActive(true);
        RefreshLabels();
    }

    public void ShowHud(int best)
    {
        HideAll();
        hudPanel.SetActive(true);
        touchPanel.SetActive(Application.isMobilePlatform);
        hudBest.text = "BEST " + best;
        cScore = cCoins = cTotal = cDist = cSpeed = -1;
    }

    public void ShowPause()
    {
        pausePanel.SetActive(true);
        touchPanel.SetActive(false);
    }

    public void ShowGameOver(int score, int best, int coins, bool newBest)
    {
        touchPanel.SetActive(false);
        overPanel.SetActive(true);
        overScore.text = "SCORE " + score;
        overBest.text = newBest ? "NEW BEST!  " + best : "BEST " + best;
        overCoins.text = "+" + coins + " coins";
    }

    public void UpdateHud(int score, int runCoins, int totalCoins, int meters, int speed)
    {
        if (score != cScore) { cScore = score; hudScore.text = score.ToString(); }
        if (runCoins != cCoins) { cCoins = runCoins; hudCoins.text = runCoins.ToString(); }
        if (totalCoins != cTotal) { cTotal = totalCoins; hudTotal.text = "TOTAL " + totalCoins; }
        if (meters != cDist) { cDist = meters; hudDist.text = meters + " m"; }
        if (speed != cSpeed) { cSpeed = speed; hudSpeed.text = "SPEED " + speed; }
    }
}
