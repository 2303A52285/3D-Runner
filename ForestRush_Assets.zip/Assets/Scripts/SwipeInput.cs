using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>Touch swipes (and mouse drags on desktop) -> lane change / jump / slide.</summary>
public class SwipeInput : MonoBehaviour
{
    PlayerController player;
    Vector2 start;
    bool tracking;

    public void Init(PlayerController p) { player = p; }

    void Update()
    {
        GameManager gm = GameManager.Instance;
        if (gm == null || player == null || gm.State != GameState.Playing) { tracking = false; return; }

        Vector2 pos; PointerPhase phase; int id;
        if (!GameInput.GetPointer(out pos, out phase, out id)) return;

        if (phase == PointerPhase.Began)
        {
            tracking = !IsOverUI(id);
            start = pos;
            return;
        }
        if (!tracking) return;
        if (phase == PointerPhase.Ended) { tracking = false; return; }

        Vector2 d = pos - start;
        float threshold = Screen.height * 0.05f / gm.SwipeSensitivity;
        if (d.magnitude < threshold) return;

        if (Mathf.Abs(d.x) > Mathf.Abs(d.y))
        {
            if (d.x > 0f) player.MoveRight(); else player.MoveLeft();
        }
        else
        {
            if (d.y > 0f) player.Jump(); else player.Slide();
        }
        start = pos;   // allows several swipes in one drag
    }

    static bool IsOverUI(int id)
    {
        EventSystem es = EventSystem.current;
        if (es == null) return false;
        return id >= 0 ? es.IsPointerOverGameObject(id) : es.IsPointerOverGameObject();
    }
}
