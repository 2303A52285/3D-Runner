using UnityEngine;

/// <summary>
/// The ONLY component that lives in the scene. When you press Play it creates the lighting, fog,
/// sky, camera, player, forest generator, audio, effects and UI, then shows the main menu.
/// </summary>
[DefaultExecutionOrder(-100)]
public class GameBootstrap : MonoBehaviour
{
    void Awake()
    {
        Application.targetFrameRate = 60;
        Time.timeScale = 1f;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        Camera cam = SetupCamera();
        SetupEnvironment(cam);

        GameObject gmGo = new GameObject("GameManager");
        GameManager gm = gmGo.AddComponent<GameManager>();
        gmGo.AddComponent<AudioManager>();
        Effects effects = new GameObject("Effects").AddComponent<Effects>();

        PlayerController player = new GameObject("Player").AddComponent<PlayerController>();
        effects.Init(player.transform);

        LevelGenerator level = new GameObject("World").AddComponent<LevelGenerator>();
        level.Init(player.transform);

        CameraFollow follow = cam.GetComponent<CameraFollow>();
        if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.Target = player.transform;

        SwipeInput swipe = new GameObject("SwipeInput").AddComponent<SwipeInput>();
        swipe.Init(player);

        UIManager ui = new GameObject("UI").AddComponent<UIManager>();
        ui.Build(gm);

        gm.Init(player, level, follow, ui);
    }

    static T FindOne<T>() where T : Object
    {
#if UNITY_2023_1_OR_NEWER
        return Object.FindFirstObjectByType<T>();
#else
        return Object.FindObjectOfType<T>();
#endif
    }

    Camera SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject go = new GameObject("Main Camera");
            go.tag = "MainCamera";
            cam = go.AddComponent<Camera>();
        }
        if (cam.GetComponent<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
        cam.fieldOfView = 62f;
        cam.nearClipPlane = 0.2f;
        cam.farClipPlane = 700f;
        cam.transform.position = new Vector3(0f, 4.4f, -8f);
        return cam;
    }

    void SetupEnvironment(Camera cam)
    {
        // Sun
        Light sun = FindOne<Light>();
        if (sun == null || sun.type != LightType.Directional)
        {
            GameObject lg = new GameObject("Sun");
            sun = lg.AddComponent<Light>();
            sun.type = LightType.Directional;
        }
        sun.color = ProceduralFactory.Hex("#FFF2D6");
        sun.intensity = 1.2f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = 0.75f;
        sun.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        RenderSettings.sun = sun;
        QualitySettings.shadowDistance = 70f;

        // Soft ambient light
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = ProceduralFactory.Hex("#9CC7F2");
        RenderSettings.ambientEquatorColor = ProceduralFactory.Hex("#8FAF8A");
        RenderSettings.ambientGroundColor = ProceduralFactory.Hex("#4B4A33");

        // Fog for atmosphere (also hides the far end of the generated forest)
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = ProceduralFactory.Hex("#BFE3F2");
        RenderSettings.fogStartDistance = 45f;
        RenderSettings.fogEndDistance = 190f;

        // Blue sky (falls back to a plain colour if the procedural skybox shader is unavailable)
        Shader skyShader = Shader.Find("Skybox/Procedural");
        if (skyShader != null)
        {
            Material sky = new Material(skyShader);
            if (sky.HasProperty("_SkyTint")) sky.SetColor("_SkyTint", new Color(0.35f, 0.6f, 0.95f));
            if (sky.HasProperty("_GroundColor")) sky.SetColor("_GroundColor", ProceduralFactory.Hex("#BFE3F2"));
            if (sky.HasProperty("_Exposure")) sky.SetFloat("_Exposure", 1.25f);
            if (sky.HasProperty("_AtmosphereThickness")) sky.SetFloat("_AtmosphereThickness", 0.9f);
            if (sky.HasProperty("_SunSize")) sky.SetFloat("_SunSize", 0.04f);
            RenderSettings.skybox = sky;
            cam.clearFlags = CameraClearFlags.Skybox;
        }
        else
        {
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = ProceduralFactory.Hex("#8CC8F0");
        }
    }
}
