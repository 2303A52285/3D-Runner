using UnityEngine;

/// <summary>Tiny pooled particle bursts (coins, dust, crash) plus glowing fireflies for a magical forest.</summary>
public class Effects : MonoBehaviour
{
    public static Effects Instance { get; private set; }

    public static Material GoldMaterial { get { return ProceduralFactory.Glow("FxGold", ProceduralFactory.Hex("#FFC83D"), 1.0f); } }
    public static Material DustMaterial { get { return ProceduralFactory.Mat("FxDust", "#C9B08A", 0.0f); } }
    public static Material HitMaterial { get { return ProceduralFactory.Glow("FxHit", ProceduralFactory.Hex("#FF5A3C"), 0.8f); } }

    class Particle
    {
        public Transform T; public Renderer R;
        public Vector3 V; public float Life, MaxLife, Size;
    }

    Particle[] pool;
    int cursor;
    Transform player;
    Transform[] flies;
    Vector3[] fliesBase;
    float[] fliesPhase;

    void Awake() { Instance = this; }

    public void Init(Transform playerTransform)
    {
        player = playerTransform;

        pool = new Particle[56];
        for (int i = 0; i < pool.Length; i++)
        {
            GameObject g = ProceduralFactory.Prim("P", PrimitiveType.Cube, GoldMaterial, transform, Vector3.zero, Vector3.one);
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            g.SetActive(false);
            Particle p = new Particle();
            p.T = g.transform; p.R = g.GetComponent<Renderer>();
            pool[i] = p;
        }

        int n = 28;
        flies = new Transform[n]; fliesBase = new Vector3[n]; fliesPhase = new float[n];
        Material glow = ProceduralFactory.Glow("Firefly", ProceduralFactory.Hex("#E9FF7A"), 2.0f);
        for (int i = 0; i < n; i++)
        {
            GameObject g = ProceduralFactory.Prim("Firefly", PrimitiveType.Sphere, glow, transform, Vector3.zero, Vector3.one * 0.14f);
            g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            flies[i] = g.transform;
            fliesBase[i] = new Vector3(0f, 0f, -9999f);
            fliesPhase[i] = Random.Range(0f, 6.28f);
        }
    }

    public void Burst(Vector3 pos, Material mat, int count, float speed, float size, float life)
    {
        if (pool == null) return;
        for (int i = 0; i < count; i++)
        {
            Particle p = pool[cursor];
            cursor = (cursor + 1) % pool.Length;
            p.T.gameObject.SetActive(true);
            p.T.position = pos;
            p.T.rotation = Random.rotation;
            p.R.sharedMaterial = mat;
            Vector3 v = Random.onUnitSphere * speed;
            v.y = Mathf.Abs(v.y) + speed * 0.3f;
            p.V = v; p.Life = life; p.MaxLife = life; p.Size = size;
        }
    }

    void Update()
    {
        float dt = Time.deltaTime;
        if (pool != null)
        {
            for (int i = 0; i < pool.Length; i++)
            {
                Particle p = pool[i];
                if (p.Life <= 0f) continue;
                p.Life -= dt;
                if (p.Life <= 0f) { p.T.gameObject.SetActive(false); continue; }
                p.V.y -= 9f * dt;
                p.T.position += p.V * dt;
                p.T.localScale = Vector3.one * p.Size * (p.Life / p.MaxLife);
            }
        }

        if (player == null || flies == null) return;
        float pz = player.position.z;
        for (int i = 0; i < flies.Length; i++)
        {
            Vector3 b = fliesBase[i];
            if (b.z < pz - 12f || b.z > pz + 110f)
            {
                b = new Vector3(Random.Range(-14f, 14f), Random.Range(0.6f, 4.5f), pz + Random.Range(5f, 90f));
                fliesBase[i] = b;
            }
            float ph = Time.time * 0.8f + fliesPhase[i];
            flies[i].position = b + new Vector3(Mathf.Sin(ph) * 0.8f, Mathf.Sin(ph * 1.3f) * 0.4f, Mathf.Cos(ph * 0.7f) * 0.8f);
        }
    }
}
