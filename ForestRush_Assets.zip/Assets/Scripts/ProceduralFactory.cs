using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Builds every material, mesh and decoration from code, so the game needs NO imported assets.
/// Materials are cloned from Unity's default primitive material, so they work in both
/// the Built-in pipeline and URP (no pink materials).
/// </summary>
public static class ProceduralFactory
{
    static Material baseMaterial;
    static readonly Dictionary<string, Material> materials = new Dictionary<string, Material>();
    static readonly Dictionary<PrimitiveType, Mesh> primitiveMeshes = new Dictionary<PrimitiveType, Mesh>();
    static Mesh coneMesh, pineMesh, rockMesh;
    static Sprite roundedSprite, coinSprite;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        baseMaterial = null; materials.Clear(); primitiveMeshes.Clear();
        coneMesh = pineMesh = rockMesh = null; roundedSprite = coinSprite = null;
    }

    public static Color Hex(string html)
    {
        Color c = Color.magenta;
        ColorUtility.TryParseHtmlString(html, out c);
        return c;
    }

    // ---------------------------------------------------------------- materials
    static Material BaseMat()
    {
        if (baseMaterial == null)
        {
            GameObject tmp = GameObject.CreatePrimitive(PrimitiveType.Cube);
            baseMaterial = tmp.GetComponent<Renderer>().sharedMaterial;
            Object.Destroy(tmp);
        }
        return baseMaterial;
    }

    public static Material Mat(string key, string hex, float smooth = 0.08f, float metallic = 0f)
    {
        return Mat(key, Hex(hex), smooth, metallic);
    }

    public static Material Mat(string key, Color color, float smooth = 0.08f, float metallic = 0f)
    {
        Material m;
        if (materials.TryGetValue(key, out m) && m != null) return m;
        m = new Material(BaseMat());
        m.name = key;
        m.color = color;
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
        m.enableInstancing = true;
        materials[key] = m;
        return m;
    }

    public static Material Glow(string key, Color color, float intensity = 1.2f)
    {
        Material m = Mat(key, color, 0.3f, 0f);
        if (m.HasProperty("_EmissionColor"))
        {
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", color * intensity);
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.None;
        }
        return m;
    }

    public static Material GoldMat()
    {
        Material m = Mat("Gold", Hex("#FFC21A"), 0.7f, 0.3f);
        if (m.HasProperty("_EmissionColor"))
        {
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", Hex("#FFB000") * 0.45f);
        }
        return m;
    }

    // ---------------------------------------------------------------- meshes
    public static Mesh PrimitiveMesh(PrimitiveType type)
    {
        Mesh m;
        if (primitiveMeshes.TryGetValue(type, out m) && m != null) return m;
        GameObject tmp = GameObject.CreatePrimitive(type);
        m = tmp.GetComponent<MeshFilter>().sharedMesh;
        Object.Destroy(tmp);
        primitiveMeshes[type] = m;
        return m;
    }

    // Adds a flat-shaded triangle whose winding is auto-corrected to face away from the Y axis.
    static void Tri(List<Vector3> v, List<int> t, Vector3 a, Vector3 b, Vector3 c)
    {
        Vector3 n = Vector3.Cross(b - a, c - a);
        Vector3 centroid = (a + b + c) / 3f;
        Vector3 outward = new Vector3(centroid.x, 0f, centroid.z);
        if (Vector3.Dot(n, outward) < 0f) { Vector3 tmp = b; b = c; c = tmp; }
        int i = v.Count;
        v.Add(a); v.Add(b); v.Add(c);
        t.Add(i); t.Add(i + 1); t.Add(i + 2);
    }

    static void AddCone(List<Vector3> v, List<int> t, float y0, float radius, float height, int seg)
    {
        Vector3 apex = new Vector3(0f, y0 + height, 0f);
        for (int i = 0; i < seg; i++)
        {
            float a0 = i * Mathf.PI * 2f / seg;
            float a1 = (i + 1) * Mathf.PI * 2f / seg;
            Vector3 p0 = new Vector3(Mathf.Cos(a0) * radius, y0, Mathf.Sin(a0) * radius);
            Vector3 p1 = new Vector3(Mathf.Cos(a1) * radius, y0, Mathf.Sin(a1) * radius);
            Tri(v, t, apex, p0, p1);
        }
    }

    static Mesh Finish(List<Vector3> v, List<int> t, string name)
    {
        Mesh m = new Mesh();
        m.name = name;
        m.SetVertices(v);
        m.SetTriangles(t, 0);
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    /// <summary>Unit cone: base radius 0.5 at y=0, tip at y=1.</summary>
    public static Mesh ConeMesh()
    {
        if (coneMesh != null) return coneMesh;
        List<Vector3> v = new List<Vector3>(); List<int> t = new List<int>();
        AddCone(v, t, 0f, 0.5f, 1f, 8);
        coneMesh = Finish(v, t, "Cone");
        return coneMesh;
    }

    /// <summary>Four stacked cones = low-poly pine foliage. Height 1, base radius 0.5.</summary>
    public static Mesh PineMesh()
    {
        if (pineMesh != null) return pineMesh;
        List<Vector3> v = new List<Vector3>(); List<int> t = new List<int>();
        AddCone(v, t, 0.00f, 0.50f, 0.45f, 7);
        AddCone(v, t, 0.25f, 0.42f, 0.40f, 7);
        AddCone(v, t, 0.48f, 0.32f, 0.32f, 7);
        AddCone(v, t, 0.68f, 0.20f, 0.32f, 7);
        pineMesh = Finish(v, t, "Pine");
        return pineMesh;
    }

    /// <summary>Faceted low-poly rock, about 1.2 wide and 0.7 tall.</summary>
    public static Mesh RockMesh()
    {
        if (rockMesh != null) return rockMesh;
        List<Vector3> v = new List<Vector3>(); List<int> t = new List<int>();
        System.Random rnd = new System.Random(12);
        int seg = 7;
        Vector3[] lo = new Vector3[seg];
        Vector3[] mid = new Vector3[seg];
        for (int i = 0; i < seg; i++)
        {
            float a = i * Mathf.PI * 2f / seg;
            float r1 = 0.42f + (float)rnd.NextDouble() * 0.12f;
            float r2 = 0.50f + (float)rnd.NextDouble() * 0.14f;
            lo[i] = new Vector3(Mathf.Cos(a) * r1, 0f, Mathf.Sin(a) * r1);
            mid[i] = new Vector3(Mathf.Cos(a + 0.2f) * r2, 0.35f + (float)rnd.NextDouble() * 0.1f, Mathf.Sin(a + 0.2f) * r2);
        }
        Vector3 top = new Vector3(0.05f, 0.7f, -0.03f);
        for (int i = 0; i < seg; i++)
        {
            int j = (i + 1) % seg;
            Tri(v, t, lo[i], lo[j], mid[j]);
            Tri(v, t, lo[i], mid[j], mid[i]);
            Tri(v, t, mid[i], mid[j], top);
        }
        rockMesh = Finish(v, t, "Rock");
        return rockMesh;
    }

    // ---------------------------------------------------------------- part helpers
    public static GameObject Part(string name, Mesh mesh, Material mat, Transform parent, Vector3 pos, Vector3 scale, Vector3 euler)
    {
        GameObject go = new GameObject(name);
        Transform tr = go.transform;
        tr.SetParent(parent, false);
        tr.localPosition = pos;
        tr.localRotation = Quaternion.Euler(euler);
        tr.localScale = scale;
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        go.AddComponent<MeshRenderer>().sharedMaterial = mat;
        return go;
    }

    public static GameObject Prim(string name, PrimitiveType type, Material mat, Transform parent, Vector3 pos, Vector3 scale)
    {
        return Part(name, PrimitiveMesh(type), mat, parent, pos, scale, Vector3.zero);
    }

    public static GameObject Prim(string name, PrimitiveType type, Material mat, Transform parent, Vector3 pos, Vector3 scale, Vector3 euler)
    {
        return Part(name, PrimitiveMesh(type), mat, parent, pos, scale, euler);
    }

    static GameObject NewRoot(string name, Transform parent)
    {
        GameObject g = new GameObject(name);
        g.transform.SetParent(parent, false);
        return g;
    }

    // ---------------------------------------------------------------- forest decorations
    public static GameObject BuildPine(Transform parent, int variant)
    {
        GameObject root = NewRoot("Pine", parent);
        string[] cols = { "#2F7D3A", "#276B33", "#3A8F47" };
        Material leaf = Mat("PineLeaf" + (variant % 3), cols[variant % 3], 0.05f);
        Prim("Trunk", PrimitiveType.Cylinder, Mat("Bark", "#5B3A22"), root.transform, new Vector3(0f, 0.9f, 0f), new Vector3(0.45f, 0.9f, 0.45f));
        Part("Foliage", PineMesh(), leaf, root.transform, new Vector3(0f, 1.3f, 0f), new Vector3(3.2f, 6.5f, 3.2f), Vector3.zero);
        return root;
    }

    public static GameObject BuildRoundTree(Transform parent, int variant)
    {
        GameObject root = NewRoot("RoundTree", parent);
        Material a = Mat("RoundLeafA", variant % 2 == 0 ? "#5FB84A" : "#78C94F", 0.05f);
        Material b = Mat("RoundLeafB", "#4AA03F", 0.05f);
        Prim("Trunk", PrimitiveType.Cylinder, Mat("Bark", "#5B3A22"), root.transform, new Vector3(0f, 1.3f, 0f), new Vector3(0.38f, 1.3f, 0.38f));
        Prim("Canopy", PrimitiveType.Sphere, a, root.transform, new Vector3(0f, 3.5f, 0f), new Vector3(3.4f, 2.8f, 3.4f));
        Prim("CanopyB", PrimitiveType.Sphere, b, root.transform, new Vector3(1.0f, 3.0f, 0.4f), new Vector3(2.4f, 2.0f, 2.4f));
        Prim("CanopyC", PrimitiveType.Sphere, b, root.transform, new Vector3(-0.9f, 3.1f, -0.3f), new Vector3(2.2f, 2.0f, 2.2f));
        return root;
    }

    public static GameObject BuildBush(Transform parent)
    {
        GameObject root = NewRoot("Bush", parent);
        Prim("BushA", PrimitiveType.Sphere, Mat("BushA", "#3F9B3E", 0.05f), root.transform, new Vector3(0f, 0.45f, 0f), new Vector3(1.5f, 1.0f, 1.4f));
        Prim("BushB", PrimitiveType.Sphere, Mat("BushB", "#58B547", 0.05f), root.transform, new Vector3(0.7f, 0.35f, 0.3f), new Vector3(1.0f, 0.8f, 1.0f));
        return root;
    }

    public static GameObject BuildRockDecor(Transform parent)
    {
        GameObject root = NewRoot("Rock", parent);
        Part("RockMesh", RockMesh(), Mat("RockDeco", "#8C918E"), root.transform, Vector3.zero, new Vector3(1.4f, 1.2f, 1.4f), Vector3.zero);
        return root;
    }

    static readonly string[] FlowerColors = { "#FF5E7E", "#FFD93B", "#FFFFFF", "#B58CFF", "#FF9A3C" };

    public static GameObject BuildFlower(Transform parent, int variant)
    {
        GameObject root = NewRoot("Flower", parent);
        int i = variant % FlowerColors.Length;
        Prim("Stem", PrimitiveType.Cylinder, Mat("Stem", "#3C8F3A"), root.transform, new Vector3(0f, 0.22f, 0f), new Vector3(0.05f, 0.22f, 0.05f));
        Prim("Head", PrimitiveType.Sphere, Mat("Flower" + i, FlowerColors[i], 0.2f), root.transform, new Vector3(0f, 0.46f, 0f), new Vector3(0.3f, 0.2f, 0.3f));
        return root;
    }

    public static GameObject BuildLogDecor(Transform parent)
    {
        GameObject root = NewRoot("Log", parent);
        Prim("LogBody", PrimitiveType.Cylinder, Mat("Bark", "#5B3A22"), root.transform, new Vector3(0f, 0.4f, 0f), new Vector3(0.4f, 1.4f, 0.4f), new Vector3(0f, 0f, 90f));
        return root;
    }

    public static GameObject BuildMushroom(Transform parent, int variant)
    {
        GameObject root = NewRoot("Mushroom", parent);
        Color capColor = variant % 2 == 0 ? Hex("#FF6FD8") : Hex("#6FD8FF");
        Prim("Stem", PrimitiveType.Cylinder, Mat("MushStem", "#F1E8D0"), root.transform, new Vector3(0f, 0.18f, 0f), new Vector3(0.12f, 0.18f, 0.12f));
        Prim("Cap", PrimitiveType.Sphere, Glow("MushCap" + (variant % 2), capColor, 1.0f), root.transform, new Vector3(0f, 0.42f, 0f), new Vector3(0.55f, 0.32f, 0.55f));
        return root;
    }

    public static GameObject BuildHill(Transform parent)
    {
        GameObject g = Part("Hill", PrimitiveMesh(PrimitiveType.Sphere), Mat("Hill", "#46893A", 0.03f), parent, Vector3.zero, Vector3.one, Vector3.zero);
        g.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        return g;
    }

    public static GameObject BuildMountain(Transform parent)
    {
        GameObject root = NewRoot("Mountain", parent);
        GameObject body = Part("Body", ConeMesh(), Mat("Mountain", "#5E8296", 0.03f), root.transform, Vector3.zero, Vector3.one, Vector3.zero);
        GameObject snow = Part("Snow", ConeMesh(), Mat("Snow", "#F4F8FB", 0.1f), root.transform, new Vector3(0f, 0.71f, 0f), new Vector3(0.31f, 0.30f, 0.31f), Vector3.zero);
        body.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        snow.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        return root;
    }

    // ---------------------------------------------------------------- UI sprites
    /// <summary>White rounded rectangle, 9-sliced, tint it with Image.color.</summary>
    public static Sprite RoundedSprite()
    {
        if (roundedSprite != null) return roundedSprite;
        const int size = 64;
        const int radius = 22;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        tex.filterMode = FilterMode.Bilinear;
        Color32[] px = new Color32[size * size];
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float cx = Mathf.Clamp(x + 0.5f, radius, size - radius);
                float cy = Mathf.Clamp(y + 0.5f, radius, size - radius);
                float dx = x + 0.5f - cx;
                float dy = y + 0.5f - cy;
                float d = Mathf.Sqrt(dx * dx + dy * dy);
                byte a = (byte)(Mathf.Clamp01(radius - d + 0.5f) * 255f);
                px[y * size + x] = new Color32(255, 255, 255, a);
            }
        }
        tex.SetPixels32(px);
        tex.Apply();
        roundedSprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0,
            SpriteMeshType.FullRect, new Vector4(radius, radius, radius, radius));
        return roundedSprite;
    }

    public static Sprite CoinSprite()
    {
        if (coinSprite != null) return coinSprite;
        const int size = 64;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        tex.filterMode = FilterMode.Bilinear;
        Color32[] px = new Color32[size * size];
        Color32 gold = new Color32(255, 205, 40, 255);
        Color32 rim = new Color32(200, 130, 10, 255);
        Color32 ring = new Color32(235, 160, 20, 255);
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dx = x + 0.5f - size * 0.5f;
                float dy = y + 0.5f - size * 0.5f;
                float r = Mathf.Sqrt(dx * dx + dy * dy);
                Color32 c = gold;
                if (r > 27f) c = rim;
                else if (r >= 18f && r <= 21f) c = ring;
                c.a = (byte)(Mathf.Clamp01(31.5f - r + 0.5f) * 255f);
                px[y * size + x] = c;
            }
        }
        tex.SetPixels32(px);
        tex.Apply();
        coinSprite = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
        return coinSprite;
    }
}
