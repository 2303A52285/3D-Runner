using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

public enum PointerPhase { Began, Held, Ended }

/// <summary>
/// One place for all input. Works with the classic Input Manager AND the new Input System,
/// so the game runs no matter which one your Unity project uses.
/// </summary>
public static class GameInput
{
#if ENABLE_LEGACY_INPUT_MANAGER
    public static bool LeftPressed() { return Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow); }
    public static bool RightPressed() { return Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow); }
    public static bool JumpPressed() { return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow); }
    public static bool SlidePressed() { return Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow); }
    public static bool PausePressed() { return Input.GetKeyDown(KeyCode.Escape); }
    public static bool RestartPressed() { return Input.GetKeyDown(KeyCode.R); }
    public static bool ConfirmPressed() { return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter); }

    public static bool GetPointer(out Vector2 pos, out PointerPhase phase, out int id)
    {
        pos = Vector2.zero; phase = PointerPhase.Held; id = -1;
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            pos = t.position; id = t.fingerId;
            if (t.phase == TouchPhase.Began) phase = PointerPhase.Began;
            else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) phase = PointerPhase.Ended;
            else phase = PointerPhase.Held;
            return true;
        }
        if (!Application.isMobilePlatform)
        {
            if (Input.GetMouseButtonDown(0)) { pos = Input.mousePosition; phase = PointerPhase.Began; return true; }
            if (Input.GetMouseButtonUp(0)) { pos = Input.mousePosition; phase = PointerPhase.Ended; return true; }
            if (Input.GetMouseButton(0)) { pos = Input.mousePosition; phase = PointerPhase.Held; return true; }
        }
        return false;
    }
#elif ENABLE_INPUT_SYSTEM
    public static bool LeftPressed() { var k = Keyboard.current; return k != null && (k.aKey.wasPressedThisFrame || k.leftArrowKey.wasPressedThisFrame); }
    public static bool RightPressed() { var k = Keyboard.current; return k != null && (k.dKey.wasPressedThisFrame || k.rightArrowKey.wasPressedThisFrame); }
    public static bool JumpPressed() { var k = Keyboard.current; return k != null && (k.spaceKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame || k.upArrowKey.wasPressedThisFrame); }
    public static bool SlidePressed() { var k = Keyboard.current; return k != null && (k.sKey.wasPressedThisFrame || k.downArrowKey.wasPressedThisFrame); }
    public static bool PausePressed() { var k = Keyboard.current; return k != null && k.escapeKey.wasPressedThisFrame; }
    public static bool RestartPressed() { var k = Keyboard.current; return k != null && k.rKey.wasPressedThisFrame; }
    public static bool ConfirmPressed() { var k = Keyboard.current; return k != null && k.enterKey.wasPressedThisFrame; }

    public static bool GetPointer(out Vector2 pos, out PointerPhase phase, out int id)
    {
        pos = Vector2.zero; phase = PointerPhase.Held; id = -1;
        var ts = Touchscreen.current;
        if (ts != null)
        {
            var t = ts.primaryTouch;
            bool began = t.press.wasPressedThisFrame;
            bool ended = t.press.wasReleasedThisFrame;
            bool held = t.press.isPressed;
            if (began || ended || held)
            {
                phase = began ? PointerPhase.Began : (ended ? PointerPhase.Ended : PointerPhase.Held);
                pos = t.position.ReadValue();
                id = t.touchId.ReadValue();
                return true;
            }
        }
        var m = Mouse.current;
        if (m != null && !Application.isMobilePlatform)
        {
            pos = m.position.ReadValue();
            if (m.leftButton.wasPressedThisFrame) { phase = PointerPhase.Began; return true; }
            if (m.leftButton.wasReleasedThisFrame) { phase = PointerPhase.Ended; return true; }
            if (m.leftButton.isPressed) { phase = PointerPhase.Held; return true; }
        }
        return false;
    }
#else
    public static bool LeftPressed() { return false; }
    public static bool RightPressed() { return false; }
    public static bool JumpPressed() { return false; }
    public static bool SlidePressed() { return false; }
    public static bool PausePressed() { return false; }
    public static bool RestartPressed() { return false; }
    public static bool ConfirmPressed() { return false; }
    public static bool GetPointer(out Vector2 pos, out PointerPhase phase, out int id) { pos = Vector2.zero; phase = PointerPhase.Held; id = -1; return false; }
#endif
}
