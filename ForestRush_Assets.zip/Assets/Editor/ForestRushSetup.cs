using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// One-click setup. Builds Assets/Scenes/ForestRunner.unity, registers it in Build Settings and
/// configures a few project settings. Runs automatically the first time the scripts compile,
/// and any time from the menu:  Forest Rush > 1. Build Game Scene (One Click)
/// </summary>
[InitializeOnLoad]
public static class ForestRushSetup
{
    const string ScenePath = "Assets/Scenes/ForestRunner.unity";

    static ForestRushSetup()
    {
        EditorApplication.delayCall += AutoSetup;
    }

    static void AutoSetup()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling) return;
        if (File.Exists(ScenePath)) return;
        if (SceneManager.GetActiveScene().isDirty) return;   // never overwrite unsaved work
        Build(false);
    }

    [MenuItem("Forest Rush/1. Build Game Scene (One Click)")]
    static void BuildFromMenu()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Build(true);
    }

    [MenuItem("Forest Rush/2. Open Game Scene")]
    static void OpenScene()
    {
        if (!File.Exists(ScenePath)) { BuildFromMenu(); return; }
        if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            EditorSceneManager.OpenScene(ScenePath);
    }

    [MenuItem("Forest Rush/Reset Saved Progress (best score + coins)")]
    static void ResetProgress()
    {
        PlayerPrefs.DeleteKey("FR_BestScore");
        PlayerPrefs.DeleteKey("FR_TotalCoins");
        PlayerPrefs.Save();
        Debug.Log("Forest Rush: saved progress cleared.");
    }

    static void EnsureFolder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder(parent + "/" + name)) AssetDatabase.CreateFolder(parent, name);
    }

    static void Build(bool announce)
    {
        EnsureFolder("Assets", "Scenes");
        EnsureFolder("Assets", "Materials");
        EnsureFolder("Assets", "Prefabs");
        EnsureFolder("Assets", "Environment");
        EnsureFolder("Assets", "Audio");

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject cam = new GameObject("Main Camera");
        cam.tag = "MainCamera";
        cam.AddComponent<Camera>();
        cam.AddComponent<AudioListener>();
        cam.transform.position = new Vector3(0f, 4.4f, -8f);

        GameObject sun = new GameObject("Directional Light");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        sun.transform.rotation = Quaternion.Euler(48f, -32f, 0f);

        new GameObject("GameBootstrap").AddComponent<GameBootstrap>();

        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

        ConfigureProject();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        if (announce)
            EditorUtility.DisplayDialog("Forest Rush",
                "Scene created:\n" + ScenePath + "\n\nPress the Play button at the top of Unity to start the game.", "OK");
        else
            Debug.Log("Forest Rush: scene created at " + ScenePath + ". Press Play!");
    }

    static void ConfigureProject()
    {
        try
        {
            PlayerSettings.productName = "Forest Rush";
            PlayerSettings.companyName = "ForestRushGames";
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
        }
        catch (System.Exception e) { Debug.LogWarning("Forest Rush: player settings skipped: " + e.Message); }

        // Make sure the shaders the game looks up by name are included in builds.
        try
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (assets != null && assets.Length > 0)
            {
                SerializedObject so = new SerializedObject(assets[0]);
                SerializedProperty list = so.FindProperty("m_AlwaysIncludedShaders");
                string[] names = { "Skybox/Procedural", "Sprites/Default", "UI/Default", "Standard", "Universal Render Pipeline/Lit" };
                foreach (string n in names)
                {
                    Shader sh = Shader.Find(n);
                    if (sh == null) continue;
                    bool found = false;
                    for (int i = 0; i < list.arraySize; i++)
                        if (list.GetArrayElementAtIndex(i).objectReferenceValue == sh) { found = true; break; }
                    if (found) continue;
                    list.arraySize++;
                    list.GetArrayElementAtIndex(list.arraySize - 1).objectReferenceValue = sh;
                }
                so.ApplyModifiedProperties();
            }
        }
        catch (System.Exception e) { Debug.LogWarning("Forest Rush: shader list skipped: " + e.Message); }
    }
}
